# RAKS Digital Solutions

A premium digital marketing agency website for **RAKS Digital Solutions**, Hyderabad.

## Tech Stack

- **Framework**: TanStack Start (React 19 + TanStack Router)
- **Styling**: Tailwind CSS v4 + custom CSS design system
- **Fonts**: Poppins (headings) + Inter (body) via Google Fonts
- **Icons**: Lucide React
- **Build**: Vite + Netlify

## Running Locally

```bash
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

## Contact Details on Site

- **Phone**: +91 70970 09770
- **Email**: raksinofficials@gmail.com
- **Address**: Hyderabad – 500040
- **WhatsApp**: +91 70970 09770
