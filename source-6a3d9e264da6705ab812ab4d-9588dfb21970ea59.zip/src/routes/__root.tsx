import { HeadContent, Scripts, createRootRoute, Outlet } from '@tanstack/react-router'
import '../styles.css'

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: 'utf-8' },
      { name: 'viewport', content: 'width=device-width, initial-scale=1' },
      { title: 'RAKS Digital Solutions – Data-Driven Digital Marketing Agency' },
      { name: 'description', content: 'RAKS Digital Solutions is a premium digital marketing agency in Hyderabad helping businesses grow with SEO, PPC, social media, and web development.' },
      { name: 'keywords', content: 'digital marketing, SEO, PPC, social media marketing, web development, Hyderabad' },
    ],
    links: [
      { rel: 'canonical', href: 'https://www.raksdigitalsolutions.online' },
      { rel: 'preconnect', href: 'https://fonts.googleapis.com' },
      { rel: 'preconnect', href: 'https://fonts.gstatic.com', crossOrigin: 'anonymous' },
      {
        rel: 'stylesheet',
        href: 'https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&family=Inter:wght@400;500;600&display=swap',
      },
      { rel: 'icon', href: '/raks-logo.png' },
    ],
  }),
  shellComponent: RootDocument,
})

function RootDocument({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  )
}
