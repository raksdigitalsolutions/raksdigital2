import { createFileRoute } from '@tanstack/react-router'
import { useState, useEffect, useRef } from 'react'
import {
  Menu, X, Phone, Mail, MapPin, ChevronDown, ArrowRight,
  Star, TrendingUp, Search, Share2, Globe, BarChart2,
  Megaphone, Code, Users, Award, CheckCircle, MessageCircle,
  Zap, Target, Eye, Heart, ExternalLink
} from 'lucide-react'

export const Route = createFileRoute('/')({
  component: HomePage,
})

// ── Whatsapp floating button ──────────────────────────────────────────────────
function WhatsAppButton() {
  return (
    <a
      href="https://wa.me/917097009770"
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 z-50 flex items-center gap-2 rounded-full px-4 py-3 animate-wa-pulse"
      style={{ background: '#25D366', color: '#fff', textDecoration: 'none', boxShadow: '0 4px 20px rgba(37,211,102,0.5)' }}
      aria-label="Chat on WhatsApp"
    >
      {/* WhatsApp SVG icon */}
      <svg width="26" height="26" viewBox="0 0 24 24" fill="currentColor">
        <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
      </svg>
      <span className="font-semibold text-sm hidden sm:block">WhatsApp Us</span>
    </a>
  )
}

// ── Header / Nav ──────────────────────────────────────────────────────────────
function Header() {
  const [menuOpen, setMenuOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const [servicesOpen, setServicesOpen] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20)
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  const navLinks = [
    { label: 'Home', href: '#hero' },
    { label: 'About', href: '#about' },
    { label: 'Services', href: '#services', hasDropdown: true },
    { label: 'Portfolio', href: '#portfolio' },
    { label: 'Testimonials', href: '#testimonials' },
    { label: 'Contact', href: '#contact' },
  ]

  const services = [
    'SEO Optimization', 'PPC Advertising', 'Social Media Marketing',
    'Web Development', 'Content Marketing', 'Email Marketing',
  ]

  return (
    <header
      className="fixed top-0 left-0 right-0 z-40 transition-all duration-300"
      style={{
        height: '90px',
        background: scrolled ? 'rgba(10,22,51,0.95)' : 'rgba(10,22,51,0.8)',
        backdropFilter: 'blur(20px)',
        borderBottom: scrolled ? '1px solid rgba(0,123,255,0.2)' : '1px solid transparent',
      }}
    >
      <div className="section-container flex items-center justify-between h-full">
        {/* Logo + Brand Name */}
        <a href="#hero" className="flex items-center gap-3" style={{ textDecoration: 'none' }}>
          <img
            src="/raks-logo.png"
            alt="RAKS Digital Solutions Logo"
            style={{ width: '52px', height: '52px', objectFit: 'contain', minWidth: '52px' }}
          />
          <div>
            <span
              className="font-bold leading-tight block"
              style={{ fontFamily: 'Poppins, sans-serif', fontSize: '1.15rem', color: '#fff', letterSpacing: '-0.01em' }}
            >
              RAKS Digital
            </span>
            <span
              className="block leading-tight"
              style={{ fontFamily: 'Poppins, sans-serif', fontSize: '0.75rem', color: '#00D4FF', letterSpacing: '0.08em', fontWeight: 600 }}
            >
              SOLUTIONS
            </span>
          </div>
        </a>

        {/* Desktop Nav */}
        <nav className="hidden lg:flex items-center gap-6">
          {navLinks.map((link) =>
            link.hasDropdown ? (
              <div key={link.label} className="relative group">
                <button
                  className="flex items-center gap-1 text-sm font-medium transition-colors"
                  style={{ color: '#D1D5DB', background: 'none', border: 'none', cursor: 'pointer', fontFamily: 'Inter, sans-serif' }}
                  onMouseEnter={() => setServicesOpen(true)}
                  onMouseLeave={() => setServicesOpen(false)}
                >
                  {link.label} <ChevronDown size={14} />
                </button>
                {servicesOpen && (
                  <div
                    className="absolute top-full left-0 mt-2 w-52 rounded-xl py-2"
                    style={{ background: '#0A1633', border: '1px solid rgba(0,123,255,0.2)', boxShadow: '0 20px 40px rgba(0,0,0,0.4)' }}
                    onMouseEnter={() => setServicesOpen(true)}
                    onMouseLeave={() => setServicesOpen(false)}
                  >
                    {services.map((s) => (
                      <a
                        key={s}
                        href="#services"
                        className="block px-4 py-2 text-sm transition-colors"
                        style={{ color: '#D1D5DB', textDecoration: 'none', fontFamily: 'Inter, sans-serif' }}
                        onMouseEnter={(e) => { (e.target as HTMLElement).style.color = '#00D4FF'; (e.target as HTMLElement).style.background = 'rgba(0,123,255,0.1)' }}
                        onMouseLeave={(e) => { (e.target as HTMLElement).style.color = '#D1D5DB'; (e.target as HTMLElement).style.background = 'transparent' }}
                      >
                        {s}
                      </a>
                    ))}
                  </div>
                )}
              </div>
            ) : (
              <a
                key={link.label}
                href={link.href}
                className="text-sm font-medium transition-colors"
                style={{ color: '#D1D5DB', textDecoration: 'none', fontFamily: 'Inter, sans-serif' }}
                onMouseEnter={(e) => { (e.target as HTMLElement).style.color = '#00D4FF' }}
                onMouseLeave={(e) => { (e.target as HTMLElement).style.color = '#D1D5DB' }}
              >
                {link.label}
              </a>
            )
          )}
        </nav>

        {/* Desktop CTA */}
        <div className="hidden lg:flex items-center gap-3">
          <a
            href="tel:+917097009770"
            className="flex items-center gap-2 text-sm font-medium px-4 py-2 rounded-xl transition-all"
            style={{ color: '#00D4FF', border: '1px solid rgba(0,212,255,0.3)', textDecoration: 'none', fontFamily: 'Inter, sans-serif' }}
            onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.background = 'rgba(0,212,255,0.1)' }}
            onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.background = 'transparent' }}
          >
            <Phone size={14} /> +91 70970 09770
          </a>
          <a href="#contact" className="btn-primary" style={{ fontSize: '0.875rem', padding: '10px 20px' }}>
            Get Free Proposal <ArrowRight size={14} />
          </a>
        </div>

        {/* Mobile hamburger */}
        <button
          className="lg:hidden p-2 rounded-lg"
          style={{ color: '#fff', background: 'rgba(0,123,255,0.1)', border: 'none', cursor: 'pointer' }}
          onClick={() => setMenuOpen(!menuOpen)}
          aria-label="Toggle menu"
        >
          {menuOpen ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div
          className="lg:hidden fixed inset-0 z-50 flex flex-col"
          style={{ background: '#0A1633', top: '90px' }}
        >
          <div className="p-6 flex flex-col gap-1">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="block py-4 px-4 text-lg font-medium rounded-xl transition-colors"
                style={{ color: '#fff', textDecoration: 'none', fontFamily: 'Poppins, sans-serif', minHeight: '48px', display: 'flex', alignItems: 'center' }}
                onClick={() => setMenuOpen(false)}
                onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.background = 'rgba(0,123,255,0.1)'; (e.currentTarget as HTMLElement).style.color = '#00D4FF' }}
                onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.background = 'transparent'; (e.currentTarget as HTMLElement).style.color = '#fff' }}
              >
                {link.label}
              </a>
            ))}
            <div className="mt-6 flex flex-col gap-3">
              <a href="tel:+917097009770" className="btn-secondary justify-center">
                <Phone size={16} /> +91 70970 09770
              </a>
              <a href="#contact" className="btn-primary justify-center" onClick={() => setMenuOpen(false)}>
                Get Free Proposal <ArrowRight size={16} />
              </a>
            </div>
          </div>
        </div>
      )}
    </header>
  )
}

// ── Hero Section ──────────────────────────────────────────────────────────────
function HeroSection() {
  const stats = [
    { value: '500+', label: 'Clients Served' },
    { value: '98%', label: 'Client Retention' },
    { value: '10x', label: 'Average ROI' },
    { value: '7+', label: 'Years Experience' },
  ]

  return (
    <section
      id="hero"
      className="relative flex items-center overflow-hidden"
      style={{ minHeight: '100vh', paddingTop: '90px', background: 'linear-gradient(135deg, #0A1633 0%, #111827 50%, #0A1633 100%)' }}
    >
      {/* Background grid */}
      <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'linear-gradient(rgba(0,123,255,0.3) 1px, transparent 1px), linear-gradient(90deg, rgba(0,123,255,0.3) 1px, transparent 1px)', backgroundSize: '60px 60px' }} />
      {/* Glow orbs */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full opacity-10 blur-3xl" style={{ background: '#007BFF' }} />
      <div className="absolute bottom-1/4 right-1/4 w-80 h-80 rounded-full opacity-10 blur-3xl" style={{ background: '#00D4FF' }} />

      <div className="section-container relative z-10 py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left */}
          <div className="animate-fade-up">
            <div
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-6 text-sm font-medium"
              style={{ background: 'rgba(0,123,255,0.15)', border: '1px solid rgba(0,123,255,0.3)', color: '#00D4FF', fontFamily: 'Inter, sans-serif' }}
            >
              <Zap size={14} /> Premium Digital Marketing Agency
            </div>
            <h1
              className="font-bold leading-tight mb-6"
              style={{ fontSize: 'clamp(2rem, 5vw, 4rem)', fontFamily: 'Poppins, sans-serif', color: '#fff' }}
            >
              Grow Your Business with{' '}
              <span className="gradient-text">Data-Driven</span>{' '}
              Digital Marketing
            </h1>
            <p
              className="mb-8 leading-relaxed"
              style={{ fontSize: '1.125rem', color: '#9CA3AF', fontFamily: 'Inter, sans-serif', maxWidth: '520px' }}
            >
              RAKS Digital Solutions delivers measurable results through strategic SEO, PPC, social media, and web development — turning your digital presence into a powerful revenue engine.
            </p>
            <div className="flex flex-wrap gap-4 mb-12">
              <a href="#contact" className="btn-primary">
                Get Free Proposal <ArrowRight size={16} />
              </a>
              <a href="#services" className="btn-secondary">
                Our Services
              </a>
            </div>
            {/* Stats row */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {stats.map((s) => (
                <div key={s.label} className="text-center p-4 rounded-2xl glass">
                  <div className="gradient-text font-bold text-2xl" style={{ fontFamily: 'Poppins, sans-serif' }}>{s.value}</div>
                  <div style={{ color: '#9CA3AF', fontSize: '0.75rem', fontFamily: 'Inter, sans-serif', marginTop: '4px' }}>{s.label}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Right – floating card illustration */}
          <div className="hidden lg:flex justify-center items-center animate-float">
            <div className="relative">
              {/* Main card */}
              <div className="rounded-3xl p-8 text-center" style={{ background: 'linear-gradient(135deg, rgba(0,123,255,0.15), rgba(0,212,255,0.1))', border: '1px solid rgba(0,123,255,0.3)', width: '360px' }}>
                <img src="/raks-logo.png" alt="RAKS" style={{ width: '100px', margin: '0 auto 16px', display: 'block' }} />
                <h3 style={{ fontFamily: 'Poppins, sans-serif', fontSize: '1.25rem', fontWeight: 700, color: '#fff', marginBottom: '8px' }}>RAKS Digital Solutions</h3>
                <p style={{ color: '#9CA3AF', fontSize: '0.875rem', fontFamily: 'Inter, sans-serif' }}>Your Growth Partner</p>
                {/* Mini metrics */}
                <div className="grid grid-cols-2 gap-3 mt-6">
                  {[
                    { icon: <TrendingUp size={18} />, label: 'Traffic +340%' },
                    { icon: <Target size={18} />, label: 'Leads +280%' },
                    { icon: <BarChart2 size={18} />, label: 'Revenue +10x' },
                    { icon: <Eye size={18} />, label: 'Reach +500%' },
                  ].map((m) => (
                    <div key={m.label} className="flex items-center gap-2 p-3 rounded-xl" style={{ background: 'rgba(0,0,0,0.3)', color: '#00D4FF', fontSize: '0.75rem', fontFamily: 'Inter, sans-serif' }}>
                      {m.icon} {m.label}
                    </div>
                  ))}
                </div>
              </div>
              {/* Decorative chips */}
              <div className="absolute -top-4 -right-4 px-4 py-2 rounded-full text-xs font-semibold" style={{ background: 'linear-gradient(135deg,#D4AF37,#FF4FA3)', color: '#fff', fontFamily: 'Poppins, sans-serif' }}>
                #1 Agency
              </div>
              <div className="absolute -bottom-4 -left-4 px-4 py-2 rounded-full text-xs font-semibold flex items-center gap-1" style={{ background: 'rgba(10,22,51,0.9)', border: '1px solid rgba(0,123,255,0.4)', color: '#00D4FF', fontFamily: 'Inter, sans-serif' }}>
                <CheckCircle size={12} /> Google Partner
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

// ── Trust / Logos Band ────────────────────────────────────────────────────────
function TrustSection() {
  const badges = ['Google Partner', 'Meta Business', 'HubSpot Certified', 'Semrush Partner', 'AWS Partner', 'ISO 9001']
  return (
    <section style={{ background: '#0A1633', padding: '40px 0', borderTop: '1px solid rgba(0,123,255,0.15)', borderBottom: '1px solid rgba(0,123,255,0.15)' }}>
      <div className="section-container">
        <p className="text-center mb-6 text-sm font-medium uppercase tracking-widest" style={{ color: '#6B7280', fontFamily: 'Inter, sans-serif' }}>Trusted Partnerships & Certifications</p>
        <div className="flex flex-wrap items-center justify-center gap-6">
          {badges.map((b) => (
            <div key={b} className="px-6 py-3 rounded-xl text-sm font-semibold glass" style={{ color: '#D1D5DB', fontFamily: 'Poppins, sans-serif' }}>
              {b}
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

// ── Services Section ──────────────────────────────────────────────────────────
function ServicesSection() {
  const services = [
    { icon: <Search size={28} />, title: 'SEO Optimization', desc: 'Dominate search rankings with data-driven keyword strategies, technical SEO, and authoritative link building that drives organic traffic.', color: '#007BFF' },
    { icon: <BarChart2 size={28} />, title: 'PPC Advertising', desc: 'Maximize ROI with precision-targeted Google Ads, Meta Ads, and LinkedIn campaigns crafted by certified professionals.', color: '#00D4FF' },
    { icon: <Share2 size={28} />, title: 'Social Media Marketing', desc: 'Build brand authority and engage your audience across Instagram, Facebook, LinkedIn, and YouTube with compelling content strategies.', color: '#D4AF37' },
    { icon: <Globe size={28} />, title: 'Web Development', desc: 'Convert visitors into customers with lightning-fast, SEO-optimized websites that reflect your brand\'s premium identity.', color: '#FF4FA3' },
    { icon: <Megaphone size={28} />, title: 'Content Marketing', desc: 'Drive inbound leads with high-value blogs, videos, infographics, and landing pages that educate and convert.', color: '#6A1B9A' },
    { icon: <Code size={28} />, title: 'Email Marketing', desc: 'Nurture leads with automated email sequences, newsletters, and personalized campaigns that turn subscribers into loyal customers.', color: '#00D4FF' },
  ]

  return (
    <section id="services" style={{ padding: '100px 0', background: '#111827' }}>
      <div className="section-container">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-4 text-sm font-medium" style={{ background: 'rgba(0,123,255,0.1)', border: '1px solid rgba(0,123,255,0.2)', color: '#007BFF', fontFamily: 'Inter, sans-serif' }}>
            <Zap size={14} /> Our Services
          </div>
          <h2 className="font-bold mb-4" style={{ fontFamily: 'Poppins, sans-serif', fontSize: 'clamp(1.75rem, 3.5vw, 3rem)', color: '#fff' }}>
            Digital Solutions That <span className="gradient-text">Deliver Results</span>
          </h2>
          <p className="mx-auto" style={{ color: '#9CA3AF', fontSize: '1.125rem', maxWidth: '560px', fontFamily: 'Inter, sans-serif' }}>
            Comprehensive digital marketing services engineered to accelerate your growth and maximise your ROI.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((s) => (
            <div
              key={s.title}
              className="card-hover rounded-3xl p-8"
              style={{ background: '#1F2937', border: '1px solid rgba(255,255,255,0.06)', cursor: 'pointer' }}
            >
              <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl mb-6" style={{ background: `${s.color}20`, color: s.color }}>
                {s.icon}
              </div>
              <h3 className="font-bold mb-3" style={{ fontFamily: 'Poppins, sans-serif', fontSize: '1.25rem', color: '#fff' }}>{s.title}</h3>
              <p style={{ color: '#9CA3AF', fontSize: '0.9375rem', lineHeight: '1.7', fontFamily: 'Inter, sans-serif' }}>{s.desc}</p>
              <div className="flex items-center gap-2 mt-6 font-medium text-sm" style={{ color: s.color, fontFamily: 'Inter, sans-serif' }}>
                Learn more <ArrowRight size={14} />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

// ── Why Choose RAKS ───────────────────────────────────────────────────────────
function WhySection() {
  const benefits = [
    { icon: <Target size={24} />, title: 'Results-Driven Strategy', desc: 'Every campaign is backed by data and calibrated to your specific business goals — no guesswork, just growth.' },
    { icon: <Users size={24} />, title: 'Expert Team', desc: 'Certified professionals across SEO, PPC, design, and development working as an extension of your team.' },
    { icon: <TrendingUp size={24} />, title: 'Proven Track Record', desc: 'Over 500 successful projects delivered across diverse industries with measurable ROI for every client.' },
    { icon: <Heart size={24} />, title: 'Client-Centric Approach', desc: 'Transparent reporting, dedicated account managers, and proactive communication at every step.' },
  ]

  return (
    <section id="about" style={{ padding: '100px 0', background: '#0A1633' }}>
      <div className="section-container">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-6 text-sm font-medium" style={{ background: 'rgba(212,175,55,0.1)', border: '1px solid rgba(212,175,55,0.3)', color: '#D4AF37', fontFamily: 'Inter, sans-serif' }}>
              <Award size={14} /> Why Choose RAKS
            </div>
            <h2 className="font-bold mb-6" style={{ fontFamily: 'Poppins, sans-serif', fontSize: 'clamp(1.75rem, 3.5vw, 3rem)', color: '#fff', lineHeight: 1.2 }}>
              We Don't Just Market — <br />
              <span className="gradient-text-brand">We Build Empires</span>
            </h2>
            <p className="mb-8" style={{ color: '#9CA3AF', fontSize: '1.0625rem', lineHeight: '1.8', fontFamily: 'Inter, sans-serif' }}>
              RAKS Digital Solutions is Hyderabad's fastest-growing premium digital agency. We combine creative excellence with analytical precision to deliver campaigns that don't just look good — they generate real, measurable business growth.
            </p>
            <a href="#contact" className="btn-primary">
              Start Your Growth Journey <ArrowRight size={16} />
            </a>
          </div>
          <div className="grid sm:grid-cols-2 gap-5">
            {benefits.map((b) => (
              <div key={b.title} className="p-6 rounded-2xl card-hover" style={{ background: '#111827', border: '1px solid rgba(0,123,255,0.15)' }}>
                <div className="w-12 h-12 rounded-xl flex items-center justify-center mb-4 gradient-bg" style={{ color: '#fff' }}>
                  {b.icon}
                </div>
                <h4 className="font-semibold mb-2" style={{ fontFamily: 'Poppins, sans-serif', color: '#fff', fontSize: '1rem' }}>{b.title}</h4>
                <p style={{ color: '#9CA3AF', fontSize: '0.875rem', lineHeight: '1.6', fontFamily: 'Inter, sans-serif' }}>{b.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

// ── Case Studies / Results ────────────────────────────────────────────────────
function CaseStudiesSection() {
  const cases = [
    { industry: 'E-Commerce', metric: '+340%', metricLabel: 'Organic Traffic', detail: 'Implemented technical SEO & content clusters — traffic tripled in 6 months', color: '#007BFF' },
    { industry: 'Real Estate', metric: '10x', metricLabel: 'Lead Generation', detail: 'Precision Google Ads & landing page CRO drove 10× qualified leads', color: '#D4AF37' },
    { industry: 'Healthcare', metric: '+280%', metricLabel: 'Social Reach', detail: 'Meta Ads + influencer strategy expanded patient reach city-wide', color: '#FF4FA3' },
  ]

  return (
    <section id="portfolio" style={{ padding: '100px 0', background: '#111827' }}>
      <div className="section-container">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-4 text-sm font-medium" style={{ background: 'rgba(0,212,255,0.1)', border: '1px solid rgba(0,212,255,0.2)', color: '#00D4FF', fontFamily: 'Inter, sans-serif' }}>
            <TrendingUp size={14} /> Case Studies
          </div>
          <h2 className="font-bold mb-4" style={{ fontFamily: 'Poppins, sans-serif', fontSize: 'clamp(1.75rem, 3.5vw, 3rem)', color: '#fff' }}>
            Real Results for <span className="gradient-text">Real Businesses</span>
          </h2>
        </div>
        <div className="grid md:grid-cols-3 gap-6">
          {cases.map((c) => (
            <div key={c.industry} className="rounded-3xl p-8 card-hover" style={{ background: '#1F2937', border: '1px solid rgba(255,255,255,0.06)' }}>
              <div className="text-xs font-semibold uppercase tracking-widest mb-4" style={{ color: c.color, fontFamily: 'Inter, sans-serif' }}>{c.industry}</div>
              <div className="font-bold mb-1" style={{ fontFamily: 'Poppins, sans-serif', fontSize: '3rem', color: '#fff', lineHeight: 1 }}>{c.metric}</div>
              <div className="font-semibold mb-4" style={{ color: c.color, fontFamily: 'Poppins, sans-serif' }}>{c.metricLabel}</div>
              <p style={{ color: '#9CA3AF', fontSize: '0.9rem', lineHeight: '1.6', fontFamily: 'Inter, sans-serif' }}>{c.detail}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

// ── Testimonials ──────────────────────────────────────────────────────────────
function TestimonialsSection() {
  const testimonials = [
    { name: 'Arun Sharma', role: 'CEO, TechVentures India', text: 'RAKS Digital transformed our online presence. In 6 months, our organic traffic tripled and leads doubled. Best investment we ever made.', stars: 5 },
    { name: 'Priya Reddy', role: 'Founder, StyleHouse', text: 'Their social media strategy took our brand from 2K to 85K followers in under a year. The team is brilliant and responsive.', stars: 5 },
    { name: 'Mohammed Ali', role: 'Director, AlphaCorp', text: 'Our Google Ads ROI went from 2x to 11x after RAKS took over. Data-driven, transparent, and highly professional.', stars: 5 },
  ]

  return (
    <section id="testimonials" style={{ padding: '100px 0', background: '#0A1633' }}>
      <div className="section-container">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-4 text-sm font-medium" style={{ background: 'rgba(212,175,55,0.1)', border: '1px solid rgba(212,175,55,0.3)', color: '#D4AF37', fontFamily: 'Inter, sans-serif' }}>
            <Star size={14} /> Testimonials
          </div>
          <h2 className="font-bold" style={{ fontFamily: 'Poppins, sans-serif', fontSize: 'clamp(1.75rem, 3.5vw, 3rem)', color: '#fff' }}>
            What Our Clients <span className="gradient-text">Say About Us</span>
          </h2>
        </div>
        <div className="grid md:grid-cols-3 gap-6">
          {testimonials.map((t) => (
            <div key={t.name} className="p-8 rounded-3xl card-hover" style={{ background: '#111827', border: '1px solid rgba(0,123,255,0.15)' }}>
              <div className="flex gap-1 mb-4">
                {Array.from({ length: t.stars }).map((_, i) => (
                  <Star key={i} size={16} fill="#D4AF37" color="#D4AF37" />
                ))}
              </div>
              <p className="mb-6" style={{ color: '#D1D5DB', fontSize: '0.9375rem', lineHeight: '1.7', fontFamily: 'Inter, sans-serif' }}>"{t.text}"</p>
              <div>
                <div className="font-semibold" style={{ color: '#fff', fontFamily: 'Poppins, sans-serif' }}>{t.name}</div>
                <div className="text-sm" style={{ color: '#6B7280', fontFamily: 'Inter, sans-serif' }}>{t.role}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

// ── Lead Gen / Free Audit Form ────────────────────────────────────────────────
function LeadGenSection() {
  const [form, setForm] = useState({ name: '', email: '', phone: '', website: '', service: '' })
  const [sent, setSent] = useState(false)
  const auditEmail = 'raksinofficials@gmail.com'

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const subject = encodeURIComponent('Free Digital Audit Request')
    const body = encodeURIComponent(
      [
        `Name: ${form.name}`,
        `Email: ${form.email}`,
        `Phone: ${form.phone}`,
        `Website: ${form.website || 'Not provided'}`,
        `Service: ${form.service}`,
      ].join('\n')
    )

    window.location.href = `mailto:${auditEmail}?subject=${subject}&body=${body}`
    setSent(true)
  }

  return (
    <section style={{ padding: '100px 0', background: 'linear-gradient(135deg, #0A1633, #111827)' }}>
      <div className="section-container">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-4 text-sm font-medium" style={{ background: 'rgba(0,123,255,0.1)', border: '1px solid rgba(0,123,255,0.2)', color: '#007BFF', fontFamily: 'Inter, sans-serif' }}>
              <Zap size={14} /> Free Offer
            </div>
            <h2 className="font-bold mb-3" style={{ fontFamily: 'Poppins, sans-serif', fontSize: 'clamp(1.5rem, 3vw, 2.5rem)', color: '#fff' }}>
              Get Your <span className="gradient-text">Free Digital Audit</span>
            </h2>
            <p style={{ color: '#9CA3AF', fontFamily: 'Inter, sans-serif' }}>Worth ₹15,000 — absolutely free. No commitment, no spam.</p>
          </div>

          {sent ? (
            <div className="text-center p-12 rounded-3xl glass-dark">
              <CheckCircle size={48} color="#00D4FF" className="mx-auto mb-4" />
              <h3 className="font-bold text-xl mb-2" style={{ fontFamily: 'Poppins, sans-serif', color: '#fff' }}>Thank You!</h3>
              <p style={{ color: '#9CA3AF', fontFamily: 'Inter, sans-serif' }}>We'll reach out within 24 hours with your free audit.</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="p-8 rounded-3xl glass-dark flex flex-col gap-4">
              {[
                { name: 'name', placeholder: 'Your Full Name', type: 'text' },
                { name: 'email', placeholder: 'Work Email Address', type: 'email' },
                { name: 'phone', placeholder: 'Phone Number', type: 'tel' },
                { name: 'website', placeholder: 'Website URL', type: 'url' },
              ].map((f) => (
                <input
                  key={f.name}
                  type={f.type}
                  placeholder={f.placeholder}
                  required={f.name !== 'website'}
                  value={(form as Record<string, string>)[f.name]}
                  onChange={(e) => setForm({ ...form, [f.name]: e.target.value })}
                  style={{
                    height: '56px', borderRadius: '12px', border: '1px solid #374151',
                    background: 'rgba(0,0,0,0.3)', color: '#fff', padding: '0 16px',
                    fontSize: '0.9375rem', fontFamily: 'Inter, sans-serif', outline: 'none',
                  }}
                  onFocus={(e) => { e.target.style.borderColor = '#007BFF' }}
                  onBlur={(e) => { e.target.style.borderColor = '#374151' }}
                />
              ))}
              <select
                required
                value={form.service}
                onChange={(e) => setForm({ ...form, service: e.target.value })}
                style={{
                  height: '56px', borderRadius: '12px', border: '1px solid #374151',
                  background: 'rgba(0,0,0,0.3)', color: form.service ? '#fff' : '#6B7280',
                  padding: '0 16px', fontSize: '0.9375rem', fontFamily: 'Inter, sans-serif', outline: 'none',
                }}
              >
                <option value="">Select a Service</option>
                <option value="seo">SEO Optimization</option>
                <option value="ppc">PPC Advertising</option>
                <option value="social">Social Media Marketing</option>
                <option value="web">Web Development</option>
                <option value="content">Content Marketing</option>
                <option value="email">Email Marketing</option>
              </select>
              <button type="submit" className="btn-primary justify-center mt-2" style={{ width: '100%', justifyContent: 'center', padding: '16px', fontSize: '1rem' }}>
                Claim My Free Audit <ArrowRight size={16} />
              </button>
            </form>
          )}
        </div>
      </div>
    </section>
  )
}

// ── Contact Section ───────────────────────────────────────────────────────────
function ContactSection() {
  const contacts = [
    { icon: <Phone size={20} />, label: 'Phone', value: '+91 70970 09770', href: 'tel:+917097009770', color: '#007BFF' },
    { icon: <Mail size={20} />, label: 'Email', value: 'raksinofficials@gmail.com', href: 'mailto:raksinofficials@gmail.com', color: '#00D4FF' },
    { icon: <MapPin size={20} />, label: 'Address', value: 'Hyderabad – 500040, Telangana', href: '#', color: '#D4AF37' },
    {
      icon: (
        <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
        </svg>
      ),
      label: 'WhatsApp',
      value: '+91 70970 09770',
      href: 'https://wa.me/917097009770',
      color: '#25D366'
    },
  ]

  return (
    <section id="contact" style={{ padding: '100px 0', background: '#0A1633' }}>
      <div className="section-container">
        <div className="text-center mb-16">
          <h2 className="font-bold mb-4" style={{ fontFamily: 'Poppins, sans-serif', fontSize: 'clamp(1.75rem, 3.5vw, 3rem)', color: '#fff' }}>
            Get In <span className="gradient-text">Touch</span>
          </h2>
          <p style={{ color: '#9CA3AF', fontFamily: 'Inter, sans-serif', fontSize: '1.0625rem' }}>Ready to accelerate your business? Let's talk.</p>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5 max-w-4xl mx-auto">
          {contacts.map((c) => (
            <a
              key={c.label}
              href={c.href}
              target={c.href.startsWith('http') ? '_blank' : undefined}
              rel="noopener noreferrer"
              className="flex flex-col items-center text-center p-6 rounded-2xl card-hover"
              style={{ background: '#111827', border: `1px solid ${c.color}30`, textDecoration: 'none', transition: 'all 0.3s' }}
            >
              <div className="w-12 h-12 rounded-xl flex items-center justify-center mb-4" style={{ background: `${c.color}20`, color: c.color }}>
                {c.icon}
              </div>
              <div className="text-xs font-semibold uppercase tracking-wider mb-2" style={{ color: '#6B7280', fontFamily: 'Inter, sans-serif' }}>{c.label}</div>
              <div className="font-medium text-sm" style={{ color: '#D1D5DB', fontFamily: 'Inter, sans-serif', wordBreak: 'break-all' }}>{c.value}</div>
            </a>
          ))}
        </div>
      </div>
    </section>
  )
}

// ── Footer ────────────────────────────────────────────────────────────────────
function Footer() {
  const year = 2026
  const services = ['SEO Optimization', 'PPC Advertising', 'Social Media Marketing', 'Web Development', 'Content Marketing', 'Email Marketing']
  const company = ['About Us', 'Our Team', 'Case Studies', 'Careers', 'Blog', 'Contact']

  return (
    <footer style={{ background: '#0A1633', borderTop: '1px solid rgba(0,123,255,0.15)', paddingTop: '80px' }}>
      <div className="section-container">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-10 pb-12">
          {/* Brand col */}
          <div className="lg:col-span-1">
            <div className="flex items-center gap-3 mb-4">
              <img src="/raks-logo.png" alt="RAKS" style={{ width: '44px', height: '44px', objectFit: 'contain' }} />
              <div>
                <div className="font-bold" style={{ fontFamily: 'Poppins, sans-serif', color: '#fff', fontSize: '1rem' }}>RAKS Digital</div>
                <div style={{ fontFamily: 'Poppins, sans-serif', color: '#00D4FF', fontSize: '0.7rem', letterSpacing: '0.08em', fontWeight: 600 }}>SOLUTIONS</div>
              </div>
            </div>
            <p className="mb-6 text-sm leading-relaxed" style={{ color: '#6B7280', fontFamily: 'Inter, sans-serif' }}>
              Hyderabad's premium digital marketing agency delivering data-driven growth strategies for ambitious businesses.
            </p>
            <div className="flex flex-col gap-2 text-sm" style={{ fontFamily: 'Inter, sans-serif' }}>
              <a href="tel:+917097009770" className="flex items-center gap-2" style={{ color: '#9CA3AF', textDecoration: 'none' }}>
                <Phone size={14} color="#007BFF" /> +91 70970 09770
              </a>
              <a href="mailto:raksinofficials@gmail.com" className="flex items-center gap-2" style={{ color: '#9CA3AF', textDecoration: 'none' }}>
                <Mail size={14} color="#007BFF" /> raksinofficials@gmail.com
              </a>
              <div className="flex items-center gap-2" style={{ color: '#9CA3AF' }}>
                <MapPin size={14} color="#007BFF" /> Hyderabad – 500040
              </div>
              <a href="https://wa.me/917097009770" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2" style={{ color: '#25D366', textDecoration: 'none' }}>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                WhatsApp Us
              </a>
              <a href="https://www.raksdigitalsolutions.online" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2" style={{ color: '#00D4FF', textDecoration: 'none' }}>
                <Globe size={14} color="#007BFF" /> www.raksdigitalsolutions.online
              </a>
            </div>
          </div>

          {/* Services */}
          <div>
            <h5 className="font-semibold mb-5" style={{ fontFamily: 'Poppins, sans-serif', color: '#fff', fontSize: '0.9375rem' }}>Services</h5>
            <ul className="flex flex-col gap-3">
              {services.map((s) => (
                <li key={s}>
                  <a href="#services" className="text-sm transition-colors" style={{ color: '#6B7280', textDecoration: 'none', fontFamily: 'Inter, sans-serif' }}
                    onMouseEnter={(e) => { (e.target as HTMLElement).style.color = '#00D4FF' }}
                    onMouseLeave={(e) => { (e.target as HTMLElement).style.color = '#6B7280' }}
                  >{s}</a>
                </li>
              ))}
            </ul>
          </div>

          {/* Company */}
          <div>
            <h5 className="font-semibold mb-5" style={{ fontFamily: 'Poppins, sans-serif', color: '#fff', fontSize: '0.9375rem' }}>Company</h5>
            <ul className="flex flex-col gap-3">
              {company.map((c) => (
                <li key={c}>
                  <a href="#about" className="text-sm transition-colors" style={{ color: '#6B7280', textDecoration: 'none', fontFamily: 'Inter, sans-serif' }}
                    onMouseEnter={(e) => { (e.target as HTMLElement).style.color = '#00D4FF' }}
                    onMouseLeave={(e) => { (e.target as HTMLElement).style.color = '#6B7280' }}
                  >{c}</a>
                </li>
              ))}
            </ul>
          </div>

          {/* CTA */}
          <div>
            <h5 className="font-semibold mb-5" style={{ fontFamily: 'Poppins, sans-serif', color: '#fff', fontSize: '0.9375rem' }}>Start Growing Today</h5>
            <p className="text-sm mb-5" style={{ color: '#6B7280', fontFamily: 'Inter, sans-serif', lineHeight: '1.6' }}>
              Free consultation and digital audit — discover your growth potential.
            </p>
            <a href="#contact" className="btn-primary" style={{ fontSize: '0.875rem', padding: '12px 20px' }}>
              Get Free Proposal <ArrowRight size={14} />
            </a>
          </div>
        </div>

        <div className="py-6 flex flex-col sm:flex-row items-center justify-between gap-3" style={{ borderTop: '1px solid rgba(255,255,255,0.06)' }}>
          <p className="text-sm" style={{ color: '#4B5563', fontFamily: 'Inter, sans-serif' }}>
            © {year} RAKS Digital Solutions. All rights reserved.
          </p>
          <p className="text-sm" style={{ color: '#4B5563', fontFamily: 'Inter, sans-serif' }}>
            Hyderabad, Telangana – 500040
          </p>
        </div>
      </div>
    </footer>
  )
}

// ── Page ──────────────────────────────────────────────────────────────────────
function HomePage() {
  return (
    <>
      <Header />
      <main>
        <HeroSection />
        <TrustSection />
        <ServicesSection />
        <WhySection />
        <CaseStudiesSection />
        <TestimonialsSection />
        <LeadGenSection />
        <ContactSection />
      </main>
      <Footer />
      <WhatsAppButton />
    </>
  )
}
